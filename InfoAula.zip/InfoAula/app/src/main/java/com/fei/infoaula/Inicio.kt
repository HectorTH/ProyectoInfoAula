package com.fei.infoaula

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView

class Inicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inicio)

        // 1. Vincular los componentes del XML con el código Kotlin
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        val toolbar = findViewById<Toolbar>(R.id.tbMenuH)
        val navigationView = findViewById<NavigationView>(R.id.navigation_view)
        val bottomNav = findViewById<BottomNavigationView>(R.id.btnNavegar2)

        // SOLUCIÓN RADICAL: Creamos una lista de estados para forzar el color Negro (#000000)
        // tanto si el icono está seleccionado como si no. Esto rompe el camuflaje de Android.
        val colorNegroSolido = android.content.res.ColorStateList.valueOf(android.graphics.Color.BLACK)
        bottomNav.itemIconTintList = colorNegroSolido  // Fuerza los iconos a negro
        bottomNav.itemTextColor = colorNegroSolido    // Fuerza los textos a negro

        // Muestra visualmente el icono de hamburguesa en la esquina de la Toolbar
        toolbar.setNavigationIcon(R.drawable.ic_menu)

        // Ajustar los márgenes dinámicos (Edge-to-Edge) de forma segura usando ViewGroup.MarginLayoutParams
        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            // Ajustar el margen superior de la Toolbar de forma segura
            (toolbar.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.topMargin = systemBars.top
                toolbar.layoutParams = params
            }

            // Ajustar el margen inferior de la barra de navegación de forma segura
            (bottomNav.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.bottomMargin = systemBars.bottom
                bottomNav.layoutParams = params
            }

            insets
        }

        // 2. Programar el clic en el menú hamburguesa para que despliegue la barra lateral
        toolbar.setNavigationOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        // 3. Programar el comportamiento al seleccionar cada opción del menú lateral (NavigationView)
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_inicio -> {
                    // Ya nos encontramos en la pantalla de Inicio
                }
                R.id.nav_salones -> {
                    val intent = Intent(this, Salones::class.java)
                    startActivity(intent)
                }
                R.id.nav_salir -> {
                    finish()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        // 4. Programar las acciones de la barra inferior (BottomNavigationView)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_inicio -> {
                    // Ya estás en Inicio
                    true
                }
                R.id.nav_buscar -> {
                    Toast.makeText(this, "Buscar aulas", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_salones -> {
                    val intent = Intent(this, Salones::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_acerca -> {
                    Toast.makeText(this, "InfoAula - Proyecto UV", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }
}