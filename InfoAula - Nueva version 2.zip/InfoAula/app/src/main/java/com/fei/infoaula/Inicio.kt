package com.fei.infoaula

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Inicio : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var tvInfo: TextView
    private lateinit var rvDatos: RecyclerView
    private var esMaestro: Boolean = false

    // CLASES DE DATOS ACTUALIZADAS PARA GUARDAR TODOS LOS CAMPOS PÚBLICOS
    data class FichaDocente(
        val nombre: String,
        val materia: String,
        val cubiculo: String,
        val correo: String,
        val numPersonal: String,
        val horarioAtencion: String
    )

    data class FichaAlumno(
        val nombre: String,
        val matricula: String,
        val carrera: String,
        val semestre: String,
        val correo: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inicio)

        try {
            auth = FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al inicializar Auth: ${e.message}", Toast.LENGTH_LONG).show()
        }

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        val toolbar = findViewById<Toolbar>(R.id.tbMenuH)
        val navigationView = findViewById<NavigationView>(R.id.navigation_view)
        val bottomNav = findViewById<BottomNavigationView>(R.id.btnNavegar2)

        tvInfo = findViewById(R.id.tvInfo)
        rvDatos = findViewById(R.id.rvDatos)
        rvDatos.layoutManager = LinearLayoutManager(this)

        val colorNegroSolido = android.content.res.ColorStateList.valueOf(android.graphics.Color.BLACK)
        bottomNav.itemIconTintList = colorNegroSolido
        bottomNav.itemTextColor = colorNegroSolido
        toolbar.setNavigationIcon(R.drawable.ic_menu)

        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            (toolbar.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.topMargin = systemBars.top
                toolbar.layoutParams = params
            }
            (bottomNav.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.bottomMargin = systemBars.bottom
                bottomNav.layoutParams = params
            }
            insets
        }

        val correoUsuario = auth.currentUser?.email ?: ""
        esMaestro = !correoUsuario.contains("estudiantes", ignoreCase = true)

        if (esMaestro) {
            tvInfo.text = "Control e Incidencias Estudiantiles:"
            cargarListaAlumnosParaMaestro()
        } else {
            tvInfo.text = "Plantilla Académica (Docentes):"
            cargarListaDocentes()
        }

        // (Menú Hamburguesa)
        toolbar.setNavigationOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        navigationView?.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_salones -> startActivity(Intent(this, Salones::class.java))
                R.id.nav_salir -> {
                    auth.signOut()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        // (Barra Inferior)
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_inicio -> true
                R.id.nav_buscar -> {
                    val intent = Intent(this, Buscar::class.java)
                    startActivity(intent)
                    true
                }
                R.id.nav_salones -> {
                    startActivity(Intent(this, Salones::class.java))
                    true
                }
                R.id.nav_acerca -> {
                    Toast.makeText(this, "InfoAula - Proyecto UV", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }

    private fun cargarListaDocentes() {
        val listaDocentes = ArrayList<FichaDocente>()
        try {
            val database = FirebaseDatabase.getInstance()
            val dbRef = database.getReference("usuarios").child("docentes")

            dbRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listaDocentes.clear()
                    if (snapshot.exists()) {
                        for (docenteSnapshot in snapshot.children) {
                            val nombre = docenteSnapshot.child("nombreProfesor").value as? String ?: "Desconocido"
                            val materia = docenteSnapshot.child("materia_principal").value as? String ?: "Sin materia"
                            val cubiculo = docenteSnapshot.child("cubiculo").value as? String ?: "Sin cubículo"
                            val correo = docenteSnapshot.child("correo").value as? String ?: "Sin correo"
                            val numPersonal = docenteSnapshot.child("numeroPersonal").value as? String ?: "S/N"
                            val horarioAtencion = docenteSnapshot.child("horario_atencion").value as? String ?: "No asignado"

                            // Guardamos todos los datos públicos en el objeto
                            listaDocentes.add(FichaDocente(nombre, materia, cubiculo, correo, numPersonal, horarioAtencion))
                        }
                    }
                    rvDatos.adapter = AdaptadorDocentes(listaDocentes)
                }
                override fun onCancelled(error: DatabaseError) {}
            })
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun cargarListaAlumnosParaMaestro() {
        val listaAlumnos = ArrayList<FichaAlumno>()
        try {
            val database = FirebaseDatabase.getInstance()
            val dbRef = database.getReference("usuarios").child("alumnos")

            dbRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listaAlumnos.clear()
                    if (snapshot.exists()) {
                        for (alumnoSnapshot in snapshot.children) {
                            val nombre = alumnoSnapshot.child("nombreAlumno").value as? String ?: "Desconocido"
                            val matricula = alumnoSnapshot.child("matricula").value as? String ?: "S/M"
                            val carrera = alumnoSnapshot.child("carrera").value as? String ?: "Sin carrera"
                            val semestre = alumnoSnapshot.child("semestre").value as? String ?: "0"
                            val correo = alumnoSnapshot.child("correo").value as? String ?: "Sin correo"

                            listaAlumnos.add(FichaAlumno(nombre, matricula, carrera, semestre, correo))
                        }
                    }
                    rvDatos.adapter = AdaptadorAlumnos(listaAlumnos)
                }
                override fun onCancelled(error: DatabaseError) {}
            })
        } catch (e: Exception) { e.printStackTrace() }
    }

    // ADAPTADOR PARA DOCENTES CON EVENTO DE CLIC EXCLUSIVO
    class AdaptadorDocentes(private val items: List<FichaDocente>) : RecyclerView.Adapter<AdaptadorDocentes.ViewHolder>() {
        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val titulo: TextView = view.findViewById(R.id.tvTituloTarjeta)
            val sub1: TextView = view.findViewById(R.id.tvSubtitulo1)
            val sub2: TextView = view.findViewById(R.id.tvSubtitulo2)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tarjeta, parent, false)
            return ViewHolder(view)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val docente = items[position]
            holder.titulo.text = docente.nombre
            holder.sub1.text = "Materia: ${docente.materia}"
            holder.sub2.text = "Ubicación: ${docente.cubiculo}"
            holder.sub2.setTextColor(android.graphics.Color.parseColor("#4CAF50"))

            // EVENTO DE CLIC: Muestra cuadro de diálogo con exclusión de campos sensibles
            holder.itemView.setOnClickListener {
                val dialog = AlertDialog.Builder(holder.itemView.context)
                    .setTitle("Información del Académico")
                    .setMessage(
                        "• Nombre: ${docente.nombre}\n" +
                                "• No. Personal: ${docente.numPersonal}\n" +
                                "• Correo: ${docente.correo}\n" +
                                "• Cubículo: ${docente.cubiculo}\n" +
                                "• Horario de Atención: ${docente.horarioAtencion}"
                    )
                    .setPositiveButton("Cerrar", null)
                    .create()
                dialog.show()
            }
        }
    }

    // ADAPTADOR PARA ALUMNOS CON EVENTO DE CLIC EXCLUSIVO
    class AdaptadorAlumnos(private val items: List<FichaAlumno>) : RecyclerView.Adapter<AdaptadorAlumnos.ViewHolder>() {
        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val titulo: TextView = view.findViewById(R.id.tvTituloTarjeta)
            val sub1: TextView = view.findViewById(R.id.tvSubtitulo1)
            val sub2: TextView = view.findViewById(R.id.tvSubtitulo2)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_tarjeta, parent, false)
            return ViewHolder(view)
        }
        override fun getItemCount(): Int = items.size
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val alumno = items[position]
            holder.titulo.text = alumno.nombre
            holder.sub1.text = "Matrícula: ${alumno.matricula}"
            holder.sub2.text = "Carrera: ${alumno.carrera}"
            holder.sub2.setTextColor(android.graphics.Color.GRAY)

            // EVENTO DE CLIC: Muestra cuadro de diálogo con exclusión de campos sensibles
            holder.itemView.setOnClickListener {
                val dialog = AlertDialog.Builder(holder.itemView.context)
                    .setTitle("Detalles del Estudiante")
                    .setMessage(
                        "• Nombre: ${alumno.nombre}\n" +
                                "• Matrícula: ${alumno.matricula}\n" +
                                "• Correo: ${alumno.correo}\n" +
                                "• Carrera: ${alumno.carrera}\n" +
                                "• Semestre: ${alumno.semestre}°"
                    )
                    .setPositiveButton("Cerrar", null)
                    .create()
                dialog.show()
            }
        }
    }
}