package com.fei.infoaula

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Locale

class Buscar : AppCompatActivity() {

    private lateinit var etBuscar: EditText
    private lateinit var lvResultados: ListView

    // Listas
    private val listaCompletaProfesores = ArrayList<String>()
    private val listaFiltrada = ArrayList<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_buscar)

        etBuscar = findViewById(R.id.etBuscar)
        lvResultados = findViewById(R.id.lvResultados)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaFiltrada)
        lvResultados.adapter = adapter

        descargarDocentes()

        etBuscar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filtrarBusqueda(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun descargarDocentes() {
        val dbRef = FirebaseDatabase.getInstance().getReference("profesores")

        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                listaCompletaProfesores.clear()

                if (snapshot.exists()) {
                    for (profesorSnapshot in snapshot.children) {
                        // Extracción exacta basándonos en tu base de datos
                        val nombre = profesorSnapshot.child("nombreProfesor").value as? String
                        val materia = profesorSnapshot.child("materia").value as? String ?: "Sin clase"
                        val contacto = profesorSnapshot.child("correo").value as? String ?: "Sin contacto"

                        if (nombre != null) {
                            listaCompletaProfesores.add("Docente: $nombre\nClase: $materia\nContacto: $contacto")
                        }
                    }
                }

                listaFiltrada.clear()
                listaFiltrada.addAll(listaCompletaProfesores)
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@Buscar, "Error al consultar datos: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun filtrarBusqueda(texto: String) {
        val query = texto.lowercase(Locale.getDefault()).trim()
        listaFiltrada.clear()

        if (query.isEmpty()) {
            listaFiltrada.addAll(listaCompletaProfesores)
        } else {
            for (item in listaCompletaProfesores) {
                if (item.lowercase(Locale.getDefault()).contains(query)) {
                    listaFiltrada.add(item)
                }
            }
        }
        adapter.notifyDataSetChanged()
    }
}