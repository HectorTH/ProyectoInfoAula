package com.fei.infoaula

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Inicio : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var tvInfo: TextView
    private lateinit var lvDatos: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inicio)

        // Inicialización segura de Firebase Auth
        try {
            auth = FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al inicializar Auth: ${e.message}", Toast.LENGTH_LONG).show()
        }

        // 1. Vincular componentes del XML
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        val toolbar = findViewById<Toolbar>(R.id.tbMenuH)
        val navigationView = findViewById<NavigationView>(R.id.navigation_view)
        val bottomNav = findViewById<BottomNavigationView>(R.id.btnNavegar2)

        tvInfo = findViewById(R.id.tvInfo)
        lvDatos = findViewById(R.id.lvDatos)

        // Configuración visual básica
        val colorNegroSolido = android.content.res.ColorStateList.valueOf(android.graphics.Color.BLACK)
        bottomNav.itemIconTintList = colorNegroSolido
        bottomNav.itemTextColor = colorNegroSolido
        toolbar.setNavigationIcon(R.drawable.ic_menu)

        // Edge-to-Edge seguro
        ViewCompat.setOnApplyWindowInsetsListener(drawerLayout) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            (toolbar.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.topMargin = systemBars.top
                toolbar.layoutParams = params
            }
            (bottomNav.layoutParams as? ViewGroup.MarginLayoutParams)?.let { params ->
                params.bottomMargin = systemBars.bottom
                bottomNav.layoutParams = params
            }
            insets
        }

        tvInfo.text = "Cargando profesores..."

        // Ejecución segura de la consulta a la base de datos
        cargarListaDocentes()

        // 2. Controladores de navegación
        toolbar.setNavigationOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }

        navigationView?.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_salones -> startActivity(Intent(this, Salones::class.java))
                R.id.nav_salir -> {
                    auth.signOut()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_inicio -> true
                R.id.nav_buscar -> {
                    Toast.makeText(this, "Buscar aulas", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.nav_salones -> {
                    startActivity(Intent(this, Salones::class.java))
                    true
                }
                R.id.nav_acerca -> {
                    Toast.makeText(this, "InfoAula - Proyecto UV", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }

    private fun cargarListaDocentes() {
        val listaDocentes = ArrayList<String>()

        try {
            // Apunta al nodo "profesores" de tu Realtime Database
            val database = FirebaseDatabase.getInstance()
            val dbRef = database.getReference("profesores")

            dbRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    listaDocentes.clear()

                    if (!snapshot.exists()) {
                        tvInfo.text = "No hay datos en Firebase"
                        listaDocentes.add("El nodo 'profesores' no contiene hijos.")
                    } else {
                        tvInfo.text = "Plantilla Académica (Docentes):"
                        for (profesorSnapshot in snapshot.children) {
                            val nombre = profesorSnapshot.child("nombreProfesor").value as? String
                            val materia = profesorSnapshot.child("materia").value as? String ?: "Sin clase"
                            val contacto = profesorSnapshot.child("correo").value as? String ?: "Sin contacto"

                            if (nombre != null) {
                                listaDocentes.add("Docente: $nombre\nClase: $materia\nContacto: $contacto")
                            }
                        }
                    }

                    // Evitar fallos si la lista se vacía por completo
                    if (listaDocentes.isEmpty()) {
                        listaDocentes.add("No se encontraron profesores válidos.")
                    }

                    // Asignación limpia del adaptador
                    val adapter = ArrayAdapter(this@Inicio, android.R.layout.simple_list_item_1, listaDocentes)
                    lvDatos.adapter = adapter
                }

                override fun onCancelled(error: DatabaseError) {
                    // SI TUS REGLAS DE SEGURIDAD RECHAZAN LA LECTURA, ESTO TE AVISARÁ:
                    tvInfo.text = "Error de Permisos"
                    Toast.makeText(this@Inicio, "Firebase bloqueado: ${error.message}", Toast.LENGTH_LONG).show()
                }
            })
        } catch (e: Exception) {
            // Captura errores de inicialización de la base de datos (como falta de google-services.json)
            tvInfo.text = "Error de configuración"
            Toast.makeText(this, "Fallo crítico en base de datos: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}